// Tab Audio Recorder — 백그라운드 서비스 워커
// 팝업·Suno 페이지·녹음용 숨은 페이지(offscreen) 사이를 이어 주고, 완성된 파일을 다운로드 폴더에 저장한다.
// 상태는 chrome.storage.session에 둔다 → 팝업을 닫았다 열어도, 서비스 워커가 잠들었다 깨어나도 이어진다.
//   cap      : 지금 켜진 탭 캡처 { mode: 'manual' | 'auto', tabId, tabTitle, format, startedAt,
//              state: 'recording' | 'encoding' | 'armed' | 'closing', take: { id, title, startedAt } | null }
//   last     : 수동 녹음의 마지막 결과 { state: 'saving' | 'done' | 'error', name, seconds, error, reason }
//   takes    : 자동 녹음한 곡 목록 (최근 것이 위) [{ id, title, state, name, seconds, partial, why, error, downloadId }]
//   encoding : 파일로 만드는 중인 곡 id 목록
//   pending  : 저장 중인 다운로드 { [downloadId]: { url, takeId, mode } }
//   notice   : 팝업에 한 번 보여 줄 안내

const OFFSCREEN_URL = 'offscreen/offscreen.html';
const SAVE_FOLDER = 'TabRecorder'; // 크롬 다운로드 폴더 안에 만들 하위 폴더
const SUNO_FOLDER = 'TabRecorder/Suno'; // 자동 녹음한 곡은 여기에
const MAX_SECONDS = 30 * 60; // 한 곡 최대 30분 (메모리 보호)
const MAX_HISTORY = 12;
const SUNO_URL = /^https:\/\/([a-z0-9-]+\.)*suno\.com\//i;

const errText = (err) => String((err && err.message) || err);
const get = (keys) => chrome.storage.session.get(keys);
const set = (items) => chrome.storage.session.set(items);
const remove = (keys) => chrome.storage.session.remove(keys);
const toOffscreen = (msg) => chrome.runtime.sendMessage({ target: 'offscreen', ...msg });

// 상태를 읽고 고치는 일은 한 줄로 세워서 차례로 처리한다 (메시지가 겹쳐 와도 서로 덮어쓰지 않게)
let queue = Promise.resolve();
function serial(fn) {
  const run = queue.then(fn);
  queue = run.catch(() => {});
  return run;
}

// ---------- 숨은 녹음 페이지 ----------

async function ensureOffscreen() {
  const docs = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'] });
  if (docs.length) return;
  await chrome.offscreen.createDocument({
    url: OFFSCREEN_URL,
    reasons: ['USER_MEDIA'],
    justification: '현재 탭의 소리를 녹음하기 위해 필요합니다.',
  });
}

// 녹음도, 변환도, 저장도 남은 게 없을 때만 닫는다 (녹음 파일(Blob)이 이 페이지 안에 있음)
async function closeOffscreenIfIdle() {
  const { cap, encoding = [], pending = {} } = await get(['cap', 'encoding', 'pending']);
  if (cap || encoding.length || Object.keys(pending).length) return;
  try {
    await chrome.offscreen.closeDocument();
  } catch (_) {}
}

// 아이콘 표시: 녹음 중 REC(빨강), 자동 녹음 대기 중 AUTO(보라)
function badge(cap) {
  let text = '';
  if (cap && cap.mode === 'manual') text = cap.state === 'recording' ? 'REC' : '';
  else if (cap) text = cap.take ? 'REC' : 'AUTO';
  chrome.action.setBadgeBackgroundColor({ color: text === 'AUTO' ? '#6c5ce7' : '#e5484d' });
  chrome.action.setBadgeText({ text });
}

// ---------- 파일 이름 ----------

function safeName(s) {
  return String(s || '')
    .replace(/[\u0000-\u001f\u007f<>:"/\\|?*]/g, '_')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 100)
    .replace(/[\s.]+$/g, '');
}

function stamp() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}_${p(d.getHours())}-${p(d.getMinutes())}-${p(d.getSeconds())}`;
}

function fileName(title, ext) {
  return `${safeName(title) || 'tab-audio'}_rec_${stamp()}.${ext}`;
}

// Suno 곡: "곡 제목_곡번호앞8자리.mp3", 끝까지 녹음하지 못했으면 "_part"
function sunoName(title, songId, ext, partial) {
  const base = safeName(String(title || '').replace(/\s*[|·–-]\s*Suno\b.*$/i, '')) || 'Suno';
  const tail = songId ? `_${songId.slice(0, 8)}` : `_rec_${stamp()}`;
  return `${base}${tail}${partial ? '_part' : ''}.${ext}`;
}

// ---------- 수동 녹음 ----------

async function startManual({ streamId, tabId, title, format, trim }) {
  const { cap } = await get('cap');
  if (cap) throw new Error(cap.mode === 'auto' ? 'Suno 자동 녹음이 켜져 있어요. 먼저 꺼 주세요.' : '이미 녹음 중이에요. 먼저 멈춰 주세요.');
  await ensureOffscreen();
  const next = { mode: 'manual', tabId, tabTitle: title || '', format, startedAt: Date.now(), state: 'recording', take: null };
  await set({ cap: next, last: null, notice: null });
  const res = await toOffscreen({ type: 'arm', mode: 'manual', streamId, format, trim, maxSeconds: MAX_SECONDS, tabTitle: title }).catch((err) => ({ ok: false, error: errText(err) }));
  if (!res || !res.ok) {
    await remove('cap');
    badge(null);
    await closeOffscreenIfIdle();
    throw new Error((res && res.error) || '녹음을 시작하지 못했어요.');
  }
  badge(next);
  return { ok: true, sampleRate: res.sampleRate, ctxState: res.ctxState };
}

async function stopManual() {
  const { cap } = await get('cap');
  if (!cap || cap.mode !== 'manual') return { ok: true };
  await set({ cap: { ...cap, state: 'encoding' } });
  try {
    await toOffscreen({ type: 'disarm', reason: 'user' });
  } catch (_) {
    await remove('cap');
    await set({ last: { state: 'error', error: '녹음 페이지를 찾을 수 없어요. 다시 녹음해 주세요.' } });
    badge(null);
  }
  return { ok: true };
}

// ---------- Suno 자동 녹음 ----------

async function autoOn({ streamId, tabId, title, url, format }) {
  const { cap } = await get('cap');
  if (cap) throw new Error(cap.mode === 'manual' ? '지금 수동 녹음 중이에요. 먼저 멈춰 주세요.' : '이미 자동 녹음이 켜져 있어요.');
  if (!SUNO_URL.test(url || '')) throw new Error('Suno(suno.com) 탭에서만 자동 녹음을 켤 수 있어요.');
  await ensureOffscreen();
  const next = { mode: 'auto', tabId, tabTitle: title || '', format, startedAt: Date.now(), state: 'armed', take: null };
  await set({ cap: next, takes: [], notice: null, last: null });
  const res = await toOffscreen({ type: 'arm', mode: 'auto', streamId, format, maxSeconds: MAX_SECONDS, tabTitle: title }).catch((err) => ({ ok: false, error: errText(err) }));
  if (!res || !res.ok) {
    await remove('cap');
    badge(null);
    await closeOffscreenIfIdle();
    throw new Error((res && res.error) || '자동 녹음을 켜지 못했어요.');
  }
  badge(next);
  await connectPage(tabId);
  return { ok: true };
}

// Suno 탭의 감시 스크립트와 연결하고, 지금 재생 상태를 알려 달라고 한다.
// 확장을 설치·업데이트하기 전부터 열려 있던 탭에는 스크립트가 없으므로 그 자리에서 넣는다.
async function connectPage(tabId) {
  const ping = () => chrome.tabs.sendMessage(tabId, { type: 'tabrec-ping', sync: true });
  try {
    await ping();
    return;
  } catch (_) {}
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ['content/suno-hook.js'], world: 'MAIN' });
    await chrome.scripting.executeScript({ target: { tabId }, files: ['content/suno-bridge.js'] });
    await ping();
  } catch (err) {
    // 연결이 안 돼도 녹음 페이지가 소리 크기로 곡을 찾는다
    console.warn('[Tab Audio Recorder] Suno 페이지 연결 실패:', errText(err));
  }
}

async function autoOff() {
  const { cap } = await get('cap');
  if (!cap || cap.mode !== 'auto') return { ok: true };
  await set({ cap: { ...cap, state: 'closing' } });
  try {
    await toOffscreen({ type: 'disarm', reason: 'off' });
  } catch (_) {
    await remove('cap');
    badge(null);
    await closeOffscreenIfIdle();
  }
  return { ok: true };
}

// 페이지 재생 신호는 자동 녹음을 켠 그 탭에서 온 것만 녹음 페이지로 넘긴다 (순서 유지)
let relayQueue = Promise.resolve();
function relayPage(data, sender) {
  const tabId = sender.tab && sender.tab.id;
  if (tabId == null || !data || typeof data !== 'object') return;
  relayQueue = relayQueue.then(async () => {
    const { cap } = await get('cap');
    if (!cap || cap.mode !== 'auto' || cap.tabId !== tabId || cap.state === 'closing') return;
    await toOffscreen({ type: 'page', data }).catch(() => {});
  });
}

// ---------- 녹음 페이지에서 오는 소식 ----------

function patchTake(takes, id, patch) {
  return takes.map((t) => (t.id === id ? { ...t, ...patch } : t));
}

async function onTakeStarted({ takeId, title, startedAt }) {
  const { cap } = await get('cap');
  if (!cap) return;
  const next = { ...cap, take: { id: takeId, title, startedAt } };
  if (cap.mode === 'auto' && cap.state === 'armed') next.state = 'recording';
  await set({ cap: next });
  badge(next);
}

async function onTakeMeta({ takeId, title }) {
  const { cap } = await get('cap');
  if (cap && cap.take && cap.take.id === takeId) await set({ cap: { ...cap, take: { ...cap.take, title } } });
}

async function onTakeEnded({ takeId, mode, title }) {
  const { cap, takes = [], encoding = [] } = await get(['cap', 'takes', 'encoding']);
  const items = { encoding: [...encoding, takeId] };
  if (cap && cap.take && cap.take.id === takeId) {
    const next = { ...cap, take: null };
    if (cap.mode === 'manual') next.state = 'encoding';
    else if (cap.state === 'recording') next.state = 'armed';
    items.cap = next;
    badge(next);
  }
  if (mode === 'auto') items.takes = [{ id: takeId, title, state: 'encoding' }, ...takes].slice(0, MAX_HISTORY);
  await set(items);
}

async function onTakeDone({ takeId, mode, url, ext, seconds, bytes, reason, partial, title, songId }) {
  const auto = mode === 'auto';
  const name = auto ? sunoName(title, songId, ext, partial) : fileName(title, ext);
  const { takes = [], encoding = [], pending = {} } = await get(['takes', 'encoding', 'pending']);
  const items = { encoding: encoding.filter((id) => id !== takeId) };
  try {
    const id = await chrome.downloads.download({ url, filename: `${auto ? SUNO_FOLDER : SAVE_FOLDER}/${name}`, conflictAction: 'uniquify', saveAs: false });
    items.pending = { ...pending, [id]: { url, takeId, mode } };
    if (auto) items.takes = patchTake(takes, takeId, { state: 'saving', name, seconds, bytes, partial });
    else items.last = { state: 'saving', name, seconds, bytes, reason };
  } catch (err) {
    const error = `파일 저장에 실패했어요: ${errText(err)}`;
    if (auto) items.takes = patchTake(takes, takeId, { state: 'error', error });
    else items.last = { state: 'error', error };
    toOffscreen({ type: 'revoke', url }).catch(() => {});
  }
  await set(items);
  if (!auto) badge((await get('cap')).cap || null);
}

async function onTakeSkipped({ takeId, mode, why, seconds }) {
  const { takes = [], encoding = [] } = await get(['takes', 'encoding']);
  const items = { encoding: encoding.filter((id) => id !== takeId) };
  if (mode === 'auto') items.takes = patchTake(takes, takeId, { state: 'skipped', why, seconds });
  await set(items);
  await closeOffscreenIfIdle();
}

async function onTakeError({ takeId, mode, error }) {
  const { takes = [], encoding = [] } = await get(['takes', 'encoding']);
  const items = { encoding: encoding.filter((id) => id !== takeId) };
  if (mode === 'auto') items.takes = patchTake(takes, takeId, { state: 'error', error });
  else items.last = { state: 'error', error };
  await set(items);
  await closeOffscreenIfIdle();
}

async function onCaptureClosed({ reason, mode }) {
  await remove('cap');
  badge(null);
  if (mode === 'auto' && reason === 'ended') await set({ notice: '녹음하던 탭이 닫혀서 자동 녹음을 껐어요.' });
  await closeOffscreenIfIdle();
}

// ---------- 저장 완료 ----------

chrome.downloads.onChanged.addListener((delta) => {
  const state = delta.state && delta.state.current;
  if (state !== 'complete' && state !== 'interrupted') return;
  serial(async () => {
    const { pending = {}, takes = [], last } = await get(['pending', 'takes', 'last']);
    const job = pending[delta.id];
    if (!job) return;
    const rest = { ...pending };
    delete rest[delta.id];
    const items = { pending: rest };
    const error = state === 'complete' ? '' : `파일 저장에 실패했어요 (${(delta.error && delta.error.current) || '알 수 없는 오류'}).`;
    const patch = error ? { state: 'error', error } : { state: 'done', downloadId: delta.id };
    if (job.mode === 'auto') items.takes = patchTake(takes, job.takeId, patch);
    else items.last = { ...last, ...patch };
    await set(items);
    toOffscreen({ type: 'revoke', url: job.url }).catch(() => {});
    await closeOffscreenIfIdle();
  });
});

// ---------- 메시지 ----------

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.target === 'offscreen') return;
  const reply = (promise) => {
    promise.then(sendResponse, (err) => sendResponse({ ok: false, error: errText(err) }));
    return true;
  };
  switch (msg.type) {
    // 팝업
    case 'start':
      return reply(serial(() => startManual(msg)));
    case 'stop':
      return reply(serial(stopManual));
    case 'auto-on':
      return reply(serial(() => autoOn(msg)));
    case 'auto-off':
      return reply(serial(autoOff));
    // Suno 페이지
    case 'page-audio':
      relayPage(msg.data, sender);
      return;
    // 녹음 페이지
    case 'take-started':
      serial(() => onTakeStarted(msg));
      return;
    case 'take-meta':
      serial(() => onTakeMeta(msg));
      return;
    case 'take-ended':
      serial(() => onTakeEnded(msg));
      return;
    case 'take-done':
      serial(() => onTakeDone(msg));
      return;
    case 'take-skipped':
      serial(() => onTakeSkipped(msg));
      return;
    case 'take-error':
      serial(() => onTakeError(msg));
      return;
    case 'capture-closed':
      serial(() => onCaptureClosed(msg));
      return;
  }
});
