// Tab Audio Recorder — Suno 페이지와 확장 사이의 다리 (확장 쪽 ISOLATED world)
// suno-hook.js가 보낸 재생 신호를 백그라운드로 넘기고, 백그라운드의 확인 요청(ping)에 답한다.

(() => {
  if (window.__tabRecBridge) return; // 다시 주입돼도 한 번만
  window.__tabRecBridge = true;

  const alive = () => {
    try {
      return !!chrome.runtime.id; // 확장을 새로 고치면 옛 스크립트는 연결이 끊긴다
    } catch (_) {
      return false;
    }
  };

  document.addEventListener('tabrec:suno', (e) => {
    if (typeof e.detail !== 'string' || !alive()) return;
    let data;
    try {
      data = JSON.parse(e.detail);
    } catch (_) {
      return;
    }
    try {
      chrome.runtime.sendMessage({ type: 'page-audio', data }).catch(() => {});
    } catch (_) {}
  });

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (!msg || msg.type !== 'tabrec-ping') return;
    sendResponse({ ok: true });
    if (msg.sync) document.dispatchEvent(new CustomEvent('tabrec:sync')); // 지금 재생 상태를 알려 달라고 요청
  });
})();
