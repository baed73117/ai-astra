// Tab Audio Recorder — Suno 페이지 안에서 도는 재생 감시 스크립트 (페이지와 같은 MAIN world)
// 페이지의 <audio>/<video> 요소가 재생·멈춤·끝날 때 그 사실만 알린다. 페이지 동작은 바꾸지 않는다.
// DOM에 붙지 않은 new Audio()도 잡으려고 HTMLMediaElement.prototype.play를 감싼다 (원래 동작 그대로 호출).
// 확장 쪽(suno-bridge.js)과는 document의 CustomEvent로 주고받는다. detail은 세계(world) 사이를
// 안전하게 넘기려고 JSON 문자열로 보낸다.

(() => {
  if (window.__tabRecSunoHook) return; // 두 번 들어와도 한 번만
  window.__tabRecSunoHook = true;

  const TO_EXT = 'tabrec:suno';
  const FROM_EXT = 'tabrec:sync';
  const UUID = /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i;
  const GENERIC = /^(suno|home|library|create|explore|search|feed|playlist|song)?$/i;

  const ids = new WeakMap(); // 요소 → 번호
  const refs = []; // 상태 알림용 (WeakRef라 요소가 사라지면 같이 사라짐)
  let nextId = 1;

  const clean = (s) => String(s || '').replace(/\s+/g, ' ').trim().slice(0, 100);

  function songIdOf(src) {
    if (!src || src.startsWith('blob:')) return ''; // blob 주소의 UUID는 곡 번호가 아님
    const m = src.match(UUID);
    return m ? m[0].toLowerCase() : '';
  }

  // 곡 제목: 미디어 세션 → 같은 곡 번호로 가는 링크 글자 → 탭 제목 순서로 찾는다
  function titleOf(songId) {
    const md = navigator.mediaSession && navigator.mediaSession.metadata;
    if (md && clean(md.title)) return clean(md.title);
    if (songId) {
      for (const a of document.querySelectorAll(`a[href*="${songId}"]`)) {
        const t = clean(a.textContent);
        if (t && !GENERIC.test(t)) return t;
      }
    }
    const t = clean(document.title.replace(/\s*[|·–-]\s*Suno\b.*$/i, ''));
    return GENERIC.test(t) ? '' : t;
  }

  function info(el) {
    const src = el.currentSrc || el.src || '';
    const songId = songIdOf(src);
    const n = ids.get(el);
    return {
      n,
      key: `${n}:${songId || src.split('?')[0].slice(0, 200)}`,
      songId,
      t: Number(el.currentTime) || 0,
      dur: Number.isFinite(el.duration) ? el.duration : 0,
      muted: !!(el.muted || el.volume === 0),
      ended: !!el.ended,
      title: titleOf(songId),
    };
  }

  function send(type, data) {
    try {
      // ts: 이 일이 실제로 일어난 시각 → 녹음 쪽에서 신호가 늦게 도착한 만큼을 계산해 정확한 곳에서 자른다
      document.dispatchEvent(new CustomEvent(TO_EXT, { detail: JSON.stringify({ type, ts: Date.now(), ...data }) }));
    } catch (_) {}
  }

  function watch(el) {
    if (!(el instanceof HTMLMediaElement) || ids.has(el)) return;
    ids.set(el, nextId++);
    refs.push(new WeakRef(el));
    el.addEventListener('playing', () => {
      send('playing', info(el));
      // 미디어 세션 제목이 재생 직후에 바뀌는 경우가 있어 한 번 더 알린다
      setTimeout(() => !el.paused && send('meta', info(el)), 1500);
    });
    el.addEventListener('pause', () => send('pause', info(el)));
    el.addEventListener('ended', () => send('ended', info(el)));
    el.addEventListener('seeked', () => send('seeked', info(el)));
    el.addEventListener('emptied', () => send('emptied', info(el)));
  }

  // 1) 스크립트로 재생하는 요소 (DOM 밖의 new Audio() 포함)
  const play = HTMLMediaElement.prototype.play;
  HTMLMediaElement.prototype.play = function (...args) {
    try {
      watch(this);
    } catch (_) {}
    return play.apply(this, args);
  };

  // 2) DOM 안에서 play()를 거치지 않고 재생되는 요소 (autoplay 등). 미디어 이벤트는 위로 올라오지 않지만
  //    캡처 단계에서는 document가 먼저 받는다. 여기서 붙인 감시는 같은 이벤트가 요소에 닿을 때 바로 불린다.
  document.addEventListener('playing', (e) => watch(e.target), true);

  // 확장이 자동 녹음을 켤 때: 지금 페이지의 재생 상태를 알려 준다
  document.addEventListener(FROM_EXT, () => {
    const playing = [];
    let count = 0;
    for (const ref of refs) {
      const el = ref.deref();
      if (!el) continue;
      count++;
      if (!el.paused && !el.ended) playing.push(info(el));
    }
    send('status', { count, playing });
  });
})();
