// 녹음용 숨은 페이지(offscreen 문서).
// 1) 탭 소리 스트림을 받아 스피커로 다시 내보내고(녹음 중에도 들리게)
// 2) AudioWorklet으로 소리를 원본 그대로 받아
// 3) 한 곡(take) 구간만 모았다가 WAV 또는 MP3로 만들어 백그라운드에 저장을 맡긴다.
//
// 녹음 방식 두 가지
//  - manual: 녹음 시작 → 바로 한 곡 녹음 → 녹음 중지 → 저장하고 캡처 종료 (예전과 같음)
//  - auto  : Suno 자동 녹음. 캡처는 켜 둔 채 기다리다가, 페이지에서 재생 신호가 오면 그 곡만 잘라 저장한다.
//            신호는 실제 소리보다 조금 늦게 도착하므로, 기다리는 동안에도 최근 소리 몇 초를 들고 있다가
//            곡 앞부분을 채운다(앞쪽 무음은 나중에 잘라 낸다).
//            페이지 신호를 못 받는 경우를 대비해, 신호가 한 번도 없으면 소리 크기로 곡의 시작·끝을 찾는다.

const SAMPLE_RATE = 48000; // MP3가 지원하는 표준 값으로 고정
const SILENCE = 33; // 약 -60dB. 이보다 작은 소리는 무음으로 본다
const TRIM_PAD_START = 0.05; // 무음 자를 때 앞쪽 여유(초)
const TRIM_PAD_END = 0.3; // 뒤쪽 여유(초) — 잔향이 잘리지 않게
const MP3_KBPS = 320;

const sec = (s) => Math.round(s * SAMPLE_RATE);
const RING = sec(3); // 기다리는 동안 들고 있는 최근 소리 길이
const PREROLL = sec(1); // 재생 신호보다 앞쪽으로 더 담는 길이 (신호가 늦게 오는 만큼 보정)
const POSTROLL = sec(0.4); // 멈춤·끝 신호 뒤로 더 담는 길이
const MIN_TAKE_SECONDS = 3; // 자동 녹음에서 이보다 짧으면 저장하지 않음 (실수로 누른 재생 등)
const PARTIAL_START = 1.5; // 곡의 이 시점(초) 뒤에서 녹음을 시작했으면 '중간부터'로 본다
const LEVEL_ON = 184; // 약 -45dB. 소리 감지 보조용 기준
const LEVEL_HOLD = sec(1.5); // 소리가 이만큼 이어지면 소리 감지로 녹음 시작
const LEVEL_GAP = sec(0.5); // 이만큼 조용하면 소리가 끊긴 것으로 본다
const LEVEL_END = sec(4); // 소리 감지 녹음은 이만큼 조용하면 끝
const MIN_GAP = sec(0.05); // 곡과 곡 사이로 볼 무음의 최소 길이

let cap = null; // 지금 켜져 있는 탭 캡처
let takeSeq = 0;

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || msg.target !== 'offscreen') return;
  switch (msg.type) {
    case 'arm':
      arm(msg).then(sendResponse, (err) => sendResponse({ ok: false, error: errText(err) }));
      return true;
    case 'disarm':
      disarm(msg.reason || 'user');
      sendResponse({ ok: true });
      return;
    case 'page':
      onPage(msg.data);
      return;
    case 'revoke':
      URL.revokeObjectURL(msg.url); // 다운로드가 끝난 파일은 메모리에서 정리
      return;
  }
});

const notify = (type, data) => chrome.runtime.sendMessage({ type, ...data }).catch(() => {});

// ---------- 캡처 켜기 / 끄기 ----------

async function arm({ streamId, mode, format, trim, maxSeconds, tabTitle }) {
  if (cap) throw new Error('이미 녹음 중이에요.');
  // 탭 소리만 받는다 (마이크 아님)
  const stream = await navigator.mediaDevices.getUserMedia({
    audio: { mandatory: { chromeMediaSource: 'tab', chromeMediaSourceId: streamId } },
    video: false,
  });
  const ctx = new AudioContext({ sampleRate: SAMPLE_RATE });
  try {
    await ctx.audioWorklet.addModule('recorder-worklet.js');
  } catch (err) {
    stream.getTracks().forEach((t) => t.stop());
    ctx.close().catch(() => {});
    throw err;
  }
  const source = ctx.createMediaStreamSource(stream);

  // 탭을 캡처하면 원래 탭 소리가 꺼지므로, 여기서 스피커로 다시 내보낸다
  source.connect(ctx.destination);

  const node = new AudioWorkletNode(ctx, 'recorder', {
    numberOfInputs: 1,
    numberOfOutputs: 1,
    outputChannelCount: [1],
    channelCount: 2,
    channelCountMode: 'explicit',
    channelInterpretation: 'speakers',
  });
  // 녹음기도 계속 돌아가도록 소리 0짜리 길로 출력에 연결
  const mute = ctx.createGain();
  mute.gain.value = 0;
  source.connect(node);
  node.connect(mute);
  mute.connect(ctx.destination);

  const auto = mode === 'auto';
  cap = {
    ctx, stream, source, node, mute,
    mode: auto ? 'auto' : 'manual',
    format: format === 'mp3' ? 'mp3' : 'wav',
    trim: auto ? true : !!trim, // 자동 녹음은 앞뒤에 여유를 담으므로 무음 자르기를 늘 켠다
    maxFrames: (Number(maxSeconds) || 1800) * SAMPLE_RATE,
    tabTitle: String(tabTitle || ''),
    clock: 0, // 캡처를 켠 뒤 지금까지 받은 프레임 수 (모든 위치 계산의 기준)
    ring: [], // 최근 소리 { l, r, start }
    ringFrames: 0,
    take: null,
    lastEnd: 0, // 앞 곡이 끝난 위치 — 다음 곡의 앞부분이 여기보다 앞으로 가지 않게
    mediaSeen: false, // 페이지 재생 신호를 받은 적이 있으면 소리 감지 보조는 쓰지 않는다
    soundStart: -1,
    lastLoud: -Infinity,
    closing: false,
  };
  node.port.onmessage = (e) => onChunk(e.data);
  for (const track of stream.getAudioTracks()) {
    track.addEventListener('ended', () => disarm('ended')); // 탭을 닫으면 자동으로 멈추고 저장
  }
  if (ctx.state !== 'running') await ctx.resume();
  if (!auto) startTake({ source: 'manual' });
  return { ok: true, sampleRate: ctx.sampleRate, ctxState: ctx.state };
}

async function disarm(reason) {
  const c = cap;
  if (!c || c.closing) return;
  c.closing = true;
  const t = c.take;
  if (t && t.endAt === null) {
    if (c.mode === 'manual' && reason === 'user') {
      stopTake(t, reason, { flush: true }); // 녹음기에 남은 마지막 조각까지 받고 끝낸다
    } else {
      stopTake(t, reason, { partial: c.mode === 'auto', now: true });
    }
  }
  if (c.take) await Promise.race([c.take.finished, wait(1500)]);
  c.stream.getTracks().forEach((tr) => tr.stop());
  c.source.disconnect();
  c.node.disconnect();
  c.mute.disconnect();
  await c.ctx.close().catch(() => {});
  if (cap === c) cap = null;
  notify('capture-closed', { reason, mode: c.mode });
}

// ---------- 소리 받기 ----------

function onChunk({ left, right, last }) {
  const c = cap;
  if (!c) return;
  if (left.length) {
    const l = toInt16(left);
    const r = toInt16(right);
    const start = c.clock;
    c.clock += l.length;
    // 최근 소리 보관 (곡 앞부분 채우기용)
    c.ring.push({ l, r, start });
    c.ringFrames += l.length;
    while (c.ring.length > 1 && c.ringFrames - c.ring[0].l.length >= RING) c.ringFrames -= c.ring.shift().l.length;
    if (c.take) appendChunk(c.take, l, r, start);
    if (c.mode === 'auto') watchLevel(c, l, r, start);
  }
  const t = c.take;
  if (!t) return;
  if (t.flush) {
    if (last) finishTake(t, c.clock);
  } else if (t.endAt !== null) {
    if (c.clock >= t.endAt) finishTake(t, cutBefore(c, t, t.endAt));
  } else if (t.frames >= c.maxFrames) {
    stopTake(t, 'limit', { partial: true, now: true });
    if (c.mode === 'manual') disarm('limit');
  }
}

// 소리 크기로 곡의 시작·끝 찾기 (페이지 재생 신호를 한 번도 못 받았을 때만)
function watchLevel(c, l, r, start) {
  let peak = 0;
  for (let i = 0; i < l.length; i++) {
    const v = Math.max(l[i] < 0 ? -l[i] : l[i], r[i] < 0 ? -r[i] : r[i]);
    if (v > peak) peak = v;
  }
  const end = start + l.length;
  if (peak > LEVEL_ON) {
    if (c.soundStart < 0 || start - c.lastLoud > LEVEL_GAP) c.soundStart = start;
    c.lastLoud = end;
  }
  if (c.mediaSeen || c.closing) return;
  const t = c.take;
  if (!t) {
    const sounding = c.soundStart >= 0 && end - c.lastLoud < LEVEL_GAP;
    if (sounding && c.lastLoud - c.soundStart >= LEVEL_HOLD) startTake({ source: 'level', from: c.soundStart - PREROLL });
  } else if (t.source === 'level' && t.endAt === null && end - c.lastLoud >= LEVEL_END) {
    stopTake(t, 'silence', { at: c.lastLoud + POSTROLL });
  }
}

// ---------- 한 곡(take) 단위 ----------

// 앞 곡을 어디서 끊을지: 끝 신호 뒤 담아 둔 꼬리에 다음 곡 소리가 섞여 들어왔으면 그 시작점에서 끊는다
function cutBefore(c, t, end) {
  if (t.source === 'manual') return end;
  const from = Math.max(t.startClock, (t.stopClock === undefined ? end : t.stopClock) - sec(2));
  const onset = newSoundAt(c, from, end);
  return onset >= 0 ? onset : end;
}

// [from, to) 구간의 끝부분이 '무음 → 새 소리'로 되어 있으면 새 소리가 시작한 위치, 아니면 -1
function newSoundAt(c, from, to) {
  let seenLoud = false;
  let run = 0;
  let onset = -1;
  for (let k = c.ring.length - 1; k >= 0; k--) {
    const ch = c.ring[k];
    if (ch.start >= to) continue;
    for (let i = Math.min(ch.l.length, to - ch.start) - 1; i >= 0; i--) {
      const pos = ch.start + i;
      if (pos < from) return -1;
      if (loud(ch.l[i]) || loud(ch.r[i])) {
        if (!seenLoud && run > 0) return -1; // 끝이 조용함 → 새 소리 없음 (앞 곡의 끝)
        seenLoud = true;
        run = 0;
      } else if (seenLoud) {
        if (run === 0) onset = pos + 1;
        if (++run >= MIN_GAP) return onset;
      } else {
        run++;
      }
    }
  }
  return -1;
}

function startTake({ source, key = '', meta = null, partial = false, from = null }) {
  const c = cap;
  if (c.take) {
    // 앞 곡이 아직 꼬리를 담는 중이면 다음 곡이 시작한 곳에서 끊고, 새 곡은 거기서부터
    const cut = cutBefore(c, c.take, c.take.endAt === null ? c.clock : Math.min(c.take.endAt, c.clock));
    finishTake(c.take, cut);
    if (from === null) from = cut;
  }
  const wanted = from !== null ? from : source === 'manual' ? c.clock : c.clock - PREROLL;
  const startClock = Math.max(wanted, c.lastEnd, 0);
  let done;
  const t = {
    id: `${Date.now().toString(36)}-${++takeSeq}`,
    mode: c.mode, format: c.format, trim: c.trim, tabTitle: c.tabTitle,
    source, key, meta, partial, reason: '',
    startClock,
    endAt: null, // 끝낼 위치 (정해지면 그때까지 받고 마무리)
    flush: false,
    frames: 0, left: [], right: [],
    finished: new Promise((resolve) => (done = resolve)),
  };
  t.resolve = done;
  for (const ch of c.ring) appendChunk(t, ch.l, ch.r, ch.start); // 이미 지나간 앞부분 채우기
  c.take = t;
  notify('take-started', {
    takeId: t.id,
    mode: t.mode,
    source,
    title: takeTitle(t),
    startedAt: Date.now() - ((c.clock - startClock) / SAMPLE_RATE) * 1000,
  });
  return t;
}

function appendChunk(t, l, r, start) {
  const skip = Math.max(t.startClock - start, 0);
  if (skip >= l.length) return;
  const sl = skip ? l.subarray(skip) : l;
  const sr = skip ? r.subarray(skip) : r;
  t.left.push(sl);
  t.right.push(sr);
  t.frames += sl.length;
}

function stopTake(t, reason, { partial = false, now = false, flush = false, at = null } = {}) {
  const c = cap;
  if (!c || c.take !== t || t.endAt !== null) return;
  t.reason = reason;
  t.stopClock = c.clock;
  if (partial) t.partial = true;
  if (flush) {
    t.flush = true;
    t.endAt = Infinity;
    c.node.port.postMessage('flush');
    setTimeout(() => cap && cap.take === t && finishTake(t, cap.clock), 1000); // 응답이 없을 때 대비
    return;
  }
  if (now) return finishTake(t, c.clock);
  t.endAt = at !== null ? at : c.clock + POSTROLL;
  if (t.endAt <= c.clock) finishTake(t, t.endAt);
}

function finishTake(t, end) {
  if (t.done) return;
  t.done = true;
  const c = cap;
  if (c && c.take === t) c.take = null;
  if (c) c.lastEnd = Math.max(c.lastEnd, end);
  const keep = Math.max(0, Math.min(end - t.startClock, t.frames));
  const left = sliceChunks(t.left, 0, keep);
  const right = sliceChunks(t.right, 0, keep);
  t.left = t.right = null;
  notify('take-ended', { takeId: t.id, mode: t.mode, title: takeTitle(t) });
  encodeTake(t, left, right, keep).finally(t.resolve);
}

async function encodeTake(t, left, right, total) {
  const base = { takeId: t.id, mode: t.mode, title: takeTitle(t), reason: t.reason };
  try {
    if (t.trim) ({ left, right } = trimSilence(left, right, total));
    const frames = left.reduce((n, c) => n + c.length, 0);
    const seconds = frames / SAMPLE_RATE;
    if (t.mode === 'auto' && seconds < MIN_TAKE_SECONDS) {
      notify('take-skipped', { ...base, seconds, why: frames ? 'short' : 'silent' });
      return;
    }
    if (!frames) throw new Error('녹음된 소리가 없어요. 탭에서 소리가 나고 있었는지 확인해 주세요.');
    const blob = t.format === 'mp3' ? await encodeMp3(left, right) : encodeWav(left, right);
    const url = URL.createObjectURL(blob);
    notify('take-done', {
      ...base,
      url,
      ext: t.format,
      seconds,
      bytes: blob.size,
      partial: !!t.partial,
      songId: (t.meta && t.meta.songId) || '',
    });
  } catch (err) {
    notify('take-error', { ...base, error: errText(err) });
  }
}

function takeTitle(t) {
  return (t.meta && t.meta.title) || t.tabTitle || '';
}

// ---------- Suno 페이지 재생 신호 ----------

const SONG_ID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;

function onPage(d) {
  const c = cap;
  if (!c || c.mode !== 'auto' || c.closing || !d || typeof d.type !== 'string') return;
  if (d.type === 'status') {
    if (Number(d.count) > 0) c.mediaSeen = true; // 페이지에 재생 요소가 있으면 재생 신호를 믿는다
    return;
  }
  const key = String(d.key || '');
  const meta = {
    title: String(d.title || '').slice(0, 100),
    songId: SONG_ID.test(d.songId) ? d.songId : '',
    t: Number(d.t) || 0,
    dur: Number(d.dur) || 0,
  };
  if (d.type === 'playing' && d.muted) return; // 소리를 끈 배경 영상 등은 무시
  c.mediaSeen = true;
  const t = c.take;
  const live = t && t.endAt === null;
  const mine = !!t && t.key === key;
  // 신호가 실제 일보다 늦게 도착한 만큼(최대 2초) 녹음 위치를 되짚는다
  const lag = Number(d.ts) > 0 ? Math.min(Math.max(Date.now() - Number(d.ts), 0), 2000) : 0;
  const happenedAt = Math.round(c.clock - (lag / 1000) * SAMPLE_RATE);

  switch (d.type) {
    case 'playing':
      if (live) {
        if (mine) return; // 버퍼링 뒤 다시 이어지는 같은 곡
        if (t.source === 'level') return adopt(t, key, meta); // 소리 감지로 먼저 시작한 녹음을 이 곡으로 이어받기
        stopTake(t, 'switch', { partial: true, at: Math.max(t.startClock, happenedAt) }); // 곡이 바뀐 그 자리에서 끊기
      }
      startTake({ source: 'media', key, meta, partial: meta.t > PARTIAL_START });
      return;
    case 'meta':
      if (mine && meta.title && meta.title !== t.meta.title) {
        t.meta.title = meta.title;
        notify('take-meta', { takeId: t.id, title: meta.title });
      }
      return;
    case 'pause':
    case 'ended': {
      if (!live || (!mine && t.source !== 'level')) return;
      const complete = d.type === 'ended' || d.ended || (meta.dur > 0 && meta.t >= meta.dur - 0.5);
      stopTake(t, complete ? 'complete' : 'pause', { partial: !complete });
      return;
    }
    case 'seeked':
      // 녹음 도중에 재생 위치를 옮기면 곡이 이어지지 않으므로 '중간까지'로 표시
      if (live && mine && c.clock - t.startClock > PREROLL + sec(0.5)) t.partial = true;
      return;
    case 'emptied':
      if (live && mine) stopTake(t, 'switch', { partial: true, at: Math.max(t.startClock, happenedAt) });
      return;
  }
}

function adopt(t, key, meta) {
  const elapsed = (cap.clock - t.startClock) / SAMPLE_RATE;
  t.source = 'media';
  t.key = key;
  t.meta = meta;
  if (meta.t > elapsed + PARTIAL_START) t.partial = true;
  notify('take-meta', { takeId: t.id, title: takeTitle(t) });
}

// ---------- 변환 ----------

function toInt16(f32) {
  const out = new Int16Array(f32.length);
  for (let i = 0; i < f32.length; i++) {
    const s = f32[i] > 1 ? 1 : f32[i] < -1 ? -1 : f32[i];
    out[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
  }
  return out;
}

function encodeWav(left, right) {
  const frames = left.reduce((n, c) => n + c.length, 0);
  const dataBytes = frames * 4; // 16비트 × 2채널
  const h = new DataView(new ArrayBuffer(44));
  const text = (offset, s) => {
    for (let i = 0; i < s.length; i++) h.setUint8(offset + i, s.charCodeAt(i));
  };
  text(0, 'RIFF');
  h.setUint32(4, 36 + dataBytes, true);
  text(8, 'WAVE');
  text(12, 'fmt ');
  h.setUint32(16, 16, true);
  h.setUint16(20, 1, true); // PCM
  h.setUint16(22, 2, true); // 스테레오
  h.setUint32(24, SAMPLE_RATE, true);
  h.setUint32(28, SAMPLE_RATE * 4, true);
  h.setUint16(32, 4, true);
  h.setUint16(34, 16, true);
  text(36, 'data');
  h.setUint32(40, dataBytes, true);

  const parts = [h.buffer];
  for (let c = 0; c < left.length; c++) {
    const l = left[c];
    const r = right[c];
    const out = new Int16Array(l.length * 2);
    for (let i = 0; i < l.length; i++) {
      out[2 * i] = l[i];
      out[2 * i + 1] = r[i];
    }
    parts.push(out);
  }
  return new Blob(parts, { type: 'audio/wav' });
}

async function encodeMp3(left, right) {
  const encoder = new lamejs.Mp3Encoder(2, SAMPLE_RATE, MP3_KBPS);
  const parts = [];
  const push = (buf) => {
    if (buf.length) parts.push(new Uint8Array(buf.buffer, buf.byteOffset, buf.length));
  };
  for (let c = 0; c < left.length; c++) {
    push(encoder.encodeBuffer(left[c], right[c]));
    if (c % 64 === 63) await wait(0); // 긴 곡에서 멈춘 것처럼 보이지 않게 잠깐씩 쉼 (다음 곡 녹음도 계속 받음)
  }
  push(encoder.flush());
  return new Blob(parts, { type: 'audio/mpeg' });
}

// ---------- 앞뒤 무음 자르기 ----------

const loud = (v) => v > SILENCE || v < -SILENCE;

function firstLoud(left, right) {
  let offset = 0;
  for (let c = 0; c < left.length; c++) {
    const l = left[c];
    const r = right[c];
    for (let i = 0; i < l.length; i++) if (loud(l[i]) || loud(r[i])) return offset + i;
    offset += l.length;
  }
  return -1;
}

function lastLoud(left, right, total) {
  let offset = total;
  for (let c = left.length - 1; c >= 0; c--) {
    const l = left[c];
    const r = right[c];
    offset -= l.length;
    for (let i = l.length - 1; i >= 0; i--) if (loud(l[i]) || loud(r[i])) return offset + i;
  }
  return -1;
}

function sliceChunks(chunks, from, to) {
  const out = [];
  let offset = 0;
  for (const chunk of chunks) {
    const a = Math.max(from - offset, 0);
    const b = Math.min(to - offset, chunk.length);
    if (a < b) out.push(a === 0 && b === chunk.length ? chunk : chunk.subarray(a, b));
    offset += chunk.length;
  }
  return out;
}

function trimSilence(left, right, total) {
  const first = firstLoud(left, right);
  if (first < 0) return { left: [], right: [] };
  const from = Math.max(0, first - Math.round(TRIM_PAD_START * SAMPLE_RATE));
  const to = Math.min(total, lastLoud(left, right, total) + 1 + Math.round(TRIM_PAD_END * SAMPLE_RATE));
  return { left: sliceChunks(left, from, to), right: sliceChunks(right, from, to) };
}

function wait(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

function errText(err) {
  return String((err && err.message) || err);
}
