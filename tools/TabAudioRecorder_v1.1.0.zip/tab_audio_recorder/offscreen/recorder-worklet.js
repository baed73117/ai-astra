// 오디오 처리 스레드에서 도는 녹음기.
// 들어오는 소리(스테레오 Float32)를 2048 프레임(약 0.04초)씩 모아 메인 쪽(offscreen.js)으로 넘긴다.
// 조각이 작을수록 곡을 자르는 위치가 정확해진다 (Suno 자동 녹음에서 곡이 바뀌는 자리).
const CHUNK_FRAMES = 2048;

class RecorderProcessor extends AudioWorkletProcessor {
  constructor() {
    super();
    this.reset();
    this.port.onmessage = (e) => {
      if (e.data === 'flush') {
        this.send(true);
      }
    };
  }

  reset() {
    this.left = new Float32Array(CHUNK_FRAMES);
    this.right = new Float32Array(CHUNK_FRAMES);
    this.pos = 0;
  }

  send(last) {
    const left = this.left.slice(0, this.pos);
    const right = this.right.slice(0, this.pos);
    this.port.postMessage({ left, right, last }, [left.buffer, right.buffer]);
    this.reset();
  }

  process(inputs) {
    const input = inputs[0];
    const frames = input && input[0] ? input[0].length : 128;
    // 소리가 잠깐 끊겨 입력이 비어도 시간 축이 밀리지 않게 무음으로 채운다
    const l = input && input[0];
    const r = input && (input[1] || input[0]);
    for (let i = 0; i < frames; i++) {
      this.left[this.pos] = l ? l[i] : 0;
      this.right[this.pos] = r ? r[i] : 0;
      this.pos++;
      if (this.pos === CHUNK_FRAMES) this.send(false);
    }
    return true;
  }
}

registerProcessor('recorder', RecorderProcessor);
