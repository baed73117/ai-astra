// Tab Audio Recorder — 팝업 화면
// 녹음 시작 / 자동 녹음 켜기 버튼을 누르면 현재 탭의 소리 스트림 ID를 받아 백그라운드에 넘긴다.
// (이 ID는 사용자가 팝업을 연 탭에 한해 크롬이 허락한다 → 자동 녹음도 탭마다 처음 한 번은 여기서 켠다)
// 화면은 chrome.storage.session의 cap / last / takes / notice 상태를 그대로 보여 준다.

const $ = (sel) => document.querySelector(sel);
const SUNO_URL = /^https:\/\/([a-z0-9-]+\.)*suno\.com\//i;
let tab = null;
let timer = 0;

init();

async function init() {
  tab = await targetTab();
  $('#tabTitle').textContent = (tab && (tab.title || tab.url)) || '알 수 없음';
  const isSuno = !!tab && SUNO_URL.test(tab.url || '');
  $('#sunoBox').hidden = !isSuno;
  $('#sunoHint').hidden = isSuno;

  const { fmt = 'wav', trim = true } = await chrome.storage.local.get(['fmt', 'trim']);
  document.querySelector(`input[name="fmt"][value="${fmt}"]`).checked = true;
  $('#trim').checked = trim;
  document.querySelectorAll('input[name="fmt"]').forEach((r) =>
    r.addEventListener('change', () => chrome.storage.local.set({ fmt: r.value }))
  );
  $('#trim').addEventListener('change', (e) => chrome.storage.local.set({ trim: e.target.checked }));

  $('#start').addEventListener('click', start);
  $('#stop').addEventListener('click', stop);
  $('#autoOn').addEventListener('click', autoOn);
  $('#autoOff').addEventListener('click', autoOff);

  render(await readState());
  chrome.storage.session.onChanged.addListener(async () => render(await readState()));
}

// 보통은 지금 보고 있는 탭. 시험할 때만 popup.html?tab=<번호>로 정할 수 있다.
async function targetTab() {
  const id = Number(new URLSearchParams(location.search).get('tab'));
  if (id) return chrome.tabs.get(id).catch(() => null);
  const [t] = await chrome.tabs.query({ active: true, currentWindow: true });
  return t || null;
}

const readState = () => chrome.storage.session.get(['cap', 'last', 'takes', 'notice']);
const format = () => document.querySelector('input[name="fmt"]:checked').value;

async function start() {
  $('#start').disabled = true;
  try {
    if (!tab) throw new Error('녹음할 탭을 찾을 수 없어요.');
    const streamId = await chrome.tabCapture.getMediaStreamId({ targetTabId: tab.id });
    const res = await chrome.runtime.sendMessage({
      type: 'start',
      streamId,
      tabId: tab.id,
      title: tab.title,
      format: format(),
      trim: $('#trim').checked,
    });
    if (!res || !res.ok) throw new Error(res && res.error);
  } catch (err) {
    await chrome.storage.session.set({ last: { state: 'error', error: friendly(err) } });
  } finally {
    $('#start').disabled = false;
  }
}

async function stop() {
  $('#stop').disabled = true;
  await chrome.runtime.sendMessage({ type: 'stop' }).catch(() => {});
  $('#stop').disabled = false;
}

async function autoOn() {
  $('#autoOn').disabled = true;
  try {
    if (!tab) throw new Error('녹음할 탭을 찾을 수 없어요.');
    const streamId = await chrome.tabCapture.getMediaStreamId({ targetTabId: tab.id });
    const res = await chrome.runtime.sendMessage({
      type: 'auto-on',
      streamId,
      tabId: tab.id,
      title: tab.title,
      url: tab.url,
      format: format(),
    });
    if (!res || !res.ok) throw new Error(res && res.error);
  } catch (err) {
    await chrome.storage.session.set({ last: { state: 'error', error: friendly(err) } });
  } finally {
    $('#autoOn').disabled = false;
  }
}

async function autoOff() {
  $('#autoOff').disabled = true;
  await chrome.runtime.sendMessage({ type: 'auto-off' }).catch(() => {});
  $('#autoOff').disabled = false;
}

function friendly(err) {
  const m = String((err && err.message) || err || '');
  if (/active stream/i.test(m)) return '이 탭은 이미 다른 곳에서 녹음(캡처) 중이에요.';
  if (/chrome pages|chrome:\/\/|cannot be captured/i.test(m)) return '크롬 설정 페이지·웹스토어 같은 곳은 녹음할 수 없어요.';
  if (/invoked|activeTab/i.test(m)) return '녹음할 탭에서 확장 아이콘을 다시 눌러 팝업을 연 뒤 시작해 주세요.';
  return m || '녹음을 시작하지 못했어요.';
}

// ---------- 화면 ----------

function render({ cap, last, takes = [], notice }) {
  const manual = cap && cap.mode === 'manual';
  const auto = cap && cap.mode === 'auto';
  $('#idle').hidden = !!cap;
  $('#recording').hidden = !manual || cap.state !== 'recording';
  $('#encoding').hidden = !manual || cap.state !== 'encoding';
  $('#auto').hidden = !auto;

  clearInterval(timer);
  if (manual && cap.state === 'recording') {
    $('#recTitle').textContent = cap.tabTitle || '';
    startTimer('#timer', cap.startedAt);
  }
  if (auto) renderAuto(cap);
  renderResult(manual ? null : last, notice);
  renderTakes(takes);
}

function renderAuto(cap) {
  const take = cap.take;
  const closing = cap.state === 'closing';
  $('#autoDot').className = take ? 'dot rec blink' : 'dot wait';
  $('#autoLabel').textContent = closing ? '자동 녹음 끄는 중…' : take ? '녹음 중' : '자동 녹음 대기 중';
  $('#autoTimer').textContent = '';
  $('#autoSongRow').hidden = !take;
  $('#autoSong').textContent = take ? take.title || '(제목 확인 중)' : '';
  $('#autoSub').textContent = take
    ? '곡이 끝나거나 멈추면 자동으로 저장해요.'
    : `Suno에서 노래를 재생하면 자동으로 녹음해요. 형식 ${String(cap.format || 'wav').toUpperCase()} · 탭 "${cap.tabTitle || ''}"`;
  if (take && !closing) startTimer('#autoTimer', take.startedAt);
}

function startTimer(sel, since) {
  const tick = () => ($(sel).textContent = mmss((Date.now() - since) / 1000));
  tick();
  timer = setInterval(tick, 500);
}

function renderResult(last, notice) {
  const box = $('#result');
  box.replaceChildren();
  box.className = '';
  if (notice) {
    box.textContent = notice;
    return;
  }
  if (!last) return;
  if (last.state === 'saving') {
    box.textContent = '파일 저장 중…';
  } else if (last.state === 'done') {
    box.className = 'ok';
    box.textContent = `저장 완료 ✓ ${last.name} (${mmss(last.seconds)})`;
    box.append(openButton(last.downloadId));
  } else if (last.state === 'error') {
    box.className = 'err';
    box.textContent = last.error;
  }
  const notes = { ended: '탭이 닫혀서 자동으로 멈추고 저장했어요.', limit: '최대 30분이 되어 자동으로 멈추고 저장했어요.' };
  if (notes[last.reason]) {
    const note = document.createElement('span');
    note.className = 'note';
    note.textContent = notes[last.reason];
    box.append(note);
  }
}

function renderTakes(takes) {
  $('#history').hidden = !takes.length;
  const list = $('#takes');
  list.replaceChildren();
  const newestDone = takes.find((t) => t.state === 'done');
  const folder = $('#openFolder');
  folder.hidden = !newestDone;
  folder.onclick = newestDone ? () => chrome.downloads.show(newestDone.downloadId) : null;

  for (const t of takes) {
    const li = document.createElement('li');
    const name = document.createElement('span');
    name.className = 'name';
    name.textContent = t.title || '(제목 없음)';
    const status = document.createElement('span');
    status.className = `status ${t.state}`;
    status.textContent = takeStatus(t);
    li.append(name, status);
    list.append(li);
  }
}

function takeStatus(t) {
  const part = t.partial ? ' · 중간까지' : '';
  switch (t.state) {
    case 'encoding':
      return '파일로 만드는 중…';
    case 'saving':
      return '저장 중…';
    case 'done':
      return `✓ ${mmss(t.seconds)}${part}`;
    case 'skipped':
      return t.why === 'silent' ? '소리가 없어 저장 안 함' : '3초 미만이라 저장 안 함';
    case 'error':
      return t.error || '오류';
    default:
      return '';
  }
}

function openButton(downloadId) {
  const open = document.createElement('button');
  open.className = 'link';
  open.textContent = '폴더 열기';
  open.addEventListener('click', () => chrome.downloads.show(downloadId));
  return open;
}

function mmss(seconds) {
  const s = Math.max(0, Math.floor(seconds || 0));
  return `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
}
